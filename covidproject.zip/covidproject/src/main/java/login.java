import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


	@WebServlet("/login")
	public class login extends HttpServlet
	 {
	PreparedStatement st=null;
	Connection con=null;
	public void init()
	{
	System.out.println("login");
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");

	}
	catch(Exception ae)
	{}
	}

	    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
	{
	        res.setContentType("text/html");
	        PrintWriter out = res.getWriter();
	       
		String a=req.getParameter("t1");
		 
	 try 
	{

	st=con.prepareStatement("select * from hospital where t2=?");
		st.setString(1,a);
		
		st.execute();
		ResultSet rs=st.executeQuery();
		if(rs.next()){
			System.out.println(rs.getString(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
			System.out.println(rs.getString(4));
		}
	}
	catch(Exception at)
	{}
	             res.sendRedirect("index.html");
		
	            out.println("</body>");
	            out.println("</html>");
	              } 

	 
	}